<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <!-- CSRF Token -->
  <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
  <title><?php echo e(config('app.name', 'Alladins | Admin Console')); ?></title>

  <?php echo $__env->make('layouts.partials.headerscripts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</head>
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">
<!-- Include header bar -->
 <?php echo $__env->make('layouts.partials.topnav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<!-- Include left side bar -->
<?php echo $__env->make('layouts.partials.leftnav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
<!-- Include content header -->
  <?php echo $__env->make('layouts.partials.contentheader', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <!-- Main content -->
    <section class="content container-fluid">    
        <?php echo $__env->yieldContent('content'); ?>
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

  <!-- Include main footer -->
  <?php echo $__env->make('layouts.partials.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

  <!-- Include Right sidebar for setting if required -->
  <?php echo $__env->make('layouts.partials.rightsidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

</div>
<!-- ./wrapper -->

<!-- Include Footer scripts -->
<?php echo $__env->make('layouts.partials.footerscripts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

</body>
</html>